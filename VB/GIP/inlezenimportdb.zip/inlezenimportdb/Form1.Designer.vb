﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.BestandToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportDBToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SluitenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.dgVrijdag = New System.Windows.Forms.DataGridView()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtFilevr = New System.Windows.Forms.TextBox()
        Me.btnVrijdag = New System.Windows.Forms.Button()
        Me.btnZaterdag = New System.Windows.Forms.Button()
        Me.txtFileza = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnZondag = New System.Windows.Forms.Button()
        Me.txtFilezo = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dgZaterdag = New System.Windows.Forms.DataGridView()
        Me.dgZondag = New System.Windows.Forms.DataGridView()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.dgVrijdag, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgZaterdag, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgZondag, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BestandToolStripMenuItem, Me.SluitenToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(778, 28)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'BestandToolStripMenuItem
        '
        Me.BestandToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ImportDBToolStripMenuItem})
        Me.BestandToolStripMenuItem.Name = "BestandToolStripMenuItem"
        Me.BestandToolStripMenuItem.Size = New System.Drawing.Size(76, 24)
        Me.BestandToolStripMenuItem.Text = "Bestand"
        '
        'ImportDBToolStripMenuItem
        '
        Me.ImportDBToolStripMenuItem.Name = "ImportDBToolStripMenuItem"
        Me.ImportDBToolStripMenuItem.Size = New System.Drawing.Size(157, 26)
        Me.ImportDBToolStripMenuItem.Text = "ImportDB"
        '
        'SluitenToolStripMenuItem
        '
        Me.SluitenToolStripMenuItem.Name = "SluitenToolStripMenuItem"
        Me.SluitenToolStripMenuItem.Size = New System.Drawing.Size(68, 24)
        Me.SluitenToolStripMenuItem.Text = "Sluiten"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'dgVrijdag
        '
        Me.dgVrijdag.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgVrijdag.Location = New System.Drawing.Point(12, 91)
        Me.dgVrijdag.Name = "dgVrijdag"
        Me.dgVrijdag.RowHeadersWidth = 51
        Me.dgVrijdag.RowTemplate.Height = 24
        Me.dgVrijdag.Size = New System.Drawing.Size(220, 278)
        Me.dgVrijdag.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(63, 442)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "file:"
        '
        'txtFilevr
        '
        Me.txtFilevr.Location = New System.Drawing.Point(109, 439)
        Me.txtFilevr.Name = "txtFilevr"
        Me.txtFilevr.Size = New System.Drawing.Size(512, 22)
        Me.txtFilevr.TabIndex = 6
        '
        'btnVrijdag
        '
        Me.btnVrijdag.Location = New System.Drawing.Point(627, 437)
        Me.btnVrijdag.Name = "btnVrijdag"
        Me.btnVrijdag.Size = New System.Drawing.Size(121, 24)
        Me.btnVrijdag.TabIndex = 7
        Me.btnVrijdag.Text = "vrijdag inlezen"
        Me.btnVrijdag.UseVisualStyleBackColor = True
        '
        'btnZaterdag
        '
        Me.btnZaterdag.Location = New System.Drawing.Point(627, 475)
        Me.btnZaterdag.Name = "btnZaterdag"
        Me.btnZaterdag.Size = New System.Drawing.Size(121, 24)
        Me.btnZaterdag.TabIndex = 10
        Me.btnZaterdag.Text = "zaterdag inlezen"
        Me.btnZaterdag.UseVisualStyleBackColor = True
        '
        'txtFileza
        '
        Me.txtFileza.Location = New System.Drawing.Point(109, 477)
        Me.txtFileza.Name = "txtFileza"
        Me.txtFileza.Size = New System.Drawing.Size(512, 22)
        Me.txtFileza.TabIndex = 9
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(63, 480)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 17)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "file:"
        '
        'btnZondag
        '
        Me.btnZondag.Location = New System.Drawing.Point(627, 515)
        Me.btnZondag.Name = "btnZondag"
        Me.btnZondag.Size = New System.Drawing.Size(121, 24)
        Me.btnZondag.TabIndex = 13
        Me.btnZondag.Text = "zondag inlezen"
        Me.btnZondag.UseVisualStyleBackColor = True
        '
        'txtFilezo
        '
        Me.txtFilezo.Location = New System.Drawing.Point(109, 519)
        Me.txtFilezo.Name = "txtFilezo"
        Me.txtFilezo.Size = New System.Drawing.Size(512, 22)
        Me.txtFilezo.TabIndex = 12
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(63, 522)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 17)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "file:"
        '
        'dgZaterdag
        '
        Me.dgZaterdag.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgZaterdag.Location = New System.Drawing.Point(285, 91)
        Me.dgZaterdag.Name = "dgZaterdag"
        Me.dgZaterdag.RowHeadersWidth = 51
        Me.dgZaterdag.RowTemplate.Height = 24
        Me.dgZaterdag.Size = New System.Drawing.Size(220, 278)
        Me.dgZaterdag.TabIndex = 14
        '
        'dgZondag
        '
        Me.dgZondag.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgZondag.Location = New System.Drawing.Point(546, 91)
        Me.dgZondag.Name = "dgZondag"
        Me.dgZondag.RowHeadersWidth = 51
        Me.dgZondag.RowTemplate.Height = 24
        Me.dgZondag.Size = New System.Drawing.Size(220, 278)
        Me.dgZondag.TabIndex = 15
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(778, 571)
        Me.Controls.Add(Me.dgZondag)
        Me.Controls.Add(Me.dgZaterdag)
        Me.Controls.Add(Me.btnZondag)
        Me.Controls.Add(Me.txtFilezo)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnZaterdag)
        Me.Controls.Add(Me.txtFileza)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnVrijdag)
        Me.Controls.Add(Me.txtFilevr)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.dgVrijdag)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.dgVrijdag, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgZaterdag, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgZondag, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents BestandToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ImportDBToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SluitenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents dgVrijdag As DataGridView
    Friend WithEvents cbSheet As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtFilevr As TextBox
    Friend WithEvents btnVrijdag As Button
    Friend WithEvents btnZaterdag As Button
    Friend WithEvents txtFileza As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents btnZondag As Button
    Friend WithEvents txtFilezo As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents dgZaterdag As DataGridView
    Friend WithEvents dgZondag As DataGridView
End Class
