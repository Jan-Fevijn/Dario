﻿Imports System.IO
Imports System.Data
Imports MySql.Data.MySqlClient
Imports Excel = Microsoft.Office.Interop.Excel
Public Class Form1
    Private xlApp As Excel.Application
    Private xlWorkBook As Excel.Workbook
    Private xlWorkSheet As Excel.Worksheet
    Private range As Excel.Range
    Private rCnt As Integer
    Private cCnt As Integer
    Private Obj As Object

    Private MyConnection As System.Data.OleDb.OleDbConnection
    Private DtSet As System.Data.DataSet
    Private MyCommand As System.Data.OleDb.OleDbDataAdapter

    Public conn As MySqlConnection
    Public connstring As String = "server=localhost;Port=3307;database=festivalstewards;uid=root;password=usbw;"
    Private Sub SluitenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SluitenToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub btnVrijdag_Click(sender As Object, e As EventArgs) Handles btnVrijdag.Click

        xlApp = New Excel.ApplicationClass
        xlWorkBook = xlApp.Workbooks.Open("C:\Users\Dario\Downloads\Shiften_vrijdag.xlsx")
        xlWorkSheet = xlWorkBook.Worksheets("Shiften Vrijdag")
        range = xlWorkSheet.UsedRange

        For rCnt = 1 To range.Rows.Count
            For cCnt = 1 To range.Columns.Count
                Obj = CType(range.Cells(rCnt, cCnt), Excel.Range)
            Next
        Next
        txtFilevr.Text = xlWorkBook.Path & "\Shiften_vrijdag"
        MessageBox.Show("u bestand is correct ingelezen")

        xlWorkBook.Close()
        xlApp.Quit()

        releaseObject(xlApp)
        releaseObject(xlWorkBook)
        releaseObject(xlWorkSheet)

        Try

            MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;" & " Data Source='C:\Users\Dario\Downloads\Shiften_Vrijdag.xlsx'; " & "Extended Properties=Excel 8.0;")
            MyCommand = New System.Data.OleDb.OleDbDataAdapter _
                ("select * from [Shiften Vrijdag]", MyConnection)
            MyCommand.TableMappings.Add("Table", "TestTable")

            DtSet = New System.Data.DataSet
            MyCommand.Fill(DtSet)

            dgVrijdag.DataSource = DtSet.Tables(0)
            MyConnection.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub btnZaterdag_Click(sender As Object, e As EventArgs) Handles btnZaterdag.Click

        xlApp = New Excel.ApplicationClass
        xlWorkBook = xlApp.Workbooks.Open("C:\Users\Dario\Downloads\Shiften_zaterdag.xlsx")
        xlWorkSheet = xlWorkBook.Worksheets("Shiften Zaterdag")
        range = xlWorkSheet.UsedRange

        For rCnt = 1 To range.Rows.Count
            For cCnt = 1 To range.Columns.Count
                Obj = CType(range.Cells(rCnt, cCnt), Excel.Range)
            Next
        Next
        txtFileza.Text = xlWorkBook.Path & "\Shiften_zaterdag"
        MessageBox.Show("u bestand is correct ingelezen")

        xlWorkBook.Close()
        xlApp.Quit()

        releaseObject(xlApp)
        releaseObject(xlWorkBook)
        releaseObject(xlWorkSheet)

        Try

            MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;" & " Data Source='C:\Users\Dario\Downloads\Shiften_Zaterdag.xlsx'; " & "Extended Properties=Excel 8.0;")
            MyCommand = New System.Data.OleDb.OleDbDataAdapter _
                ("select * from [Shiften Zaterdag]", MyConnection)
            MyCommand.TableMappings.Add("Table", "TestTable")

            DtSet = New System.Data.DataSet
            MyCommand.Fill(DtSet)

            dgZaterdag.DataSource = DtSet.Tables(0)
            MyConnection.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub btnZondag_Click(sender As Object, e As EventArgs) Handles btnZondag.Click

        xlApp = New Excel.ApplicationClass
        xlWorkBook = xlApp.Workbooks.Open("C:\Users\Dario\Downloads\Shiften_Zondag.xlsx")
        xlWorkSheet = xlWorkBook.Worksheets("Shiften Zondag")
        range = xlWorkSheet.UsedRange

        For rCnt = 1 To range.Rows.Count
            For cCnt = 1 To range.Columns.Count
                Obj = CType(range.Cells(rCnt, cCnt), Excel.Range)
            Next
        Next
        txtFilezo.Text = xlWorkBook.Path & "\Shiften_zondag"
        MessageBox.Show("u bestand is correct ingelezen")

        xlWorkBook.Close()
        xlApp.Quit()

        releaseObject(xlApp)
        releaseObject(xlWorkBook)
        releaseObject(xlWorkSheet)

        Try

            MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;" & " Data Source='C:\Users\Dario\Downloads\Shiften_zondag.xlsx'; " & "Extended Properties=Excel 8.0;")
            MyCommand = New System.Data.OleDb.OleDbDataAdapter _
                ("select * from [Shiften Zondag]", MyConnection)
            MyCommand.TableMappings.Add("Table", "TestTable")

            DtSet = New System.Data.DataSet
            MyCommand.Fill(DtSet)

            dgZondag.DataSource = DtSet.Tables(0)
            MyConnection.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub ImportDBToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ImportDBToolStripMenuItem.Click

    End Sub
End Class