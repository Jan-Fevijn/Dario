﻿Imports System.IO
Imports ExcelDataReader
Imports MySql.Data.MySqlClient

Public Class Form1
    Private tables As DataTableCollection
    Public conn As MySqlConnection
    Public connstring As String = "server=localhost;Port=3307;database=festivalstewards;uid=root;password=usbw;"
    Private Sub SluitenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SluitenToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub ImportDBToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ImportDBToolStripMenuItem.Click

    End Sub

    Private Sub btnBrows_Click(sender As Object, e As EventArgs) Handles btnBrows.Click
        Using ofd As OpenFileDialog = New OpenFileDialog() 'With {.Filter = "Excel 97-2003 Workbook|*.xls|Excel Workbook|*.xlsx"}

            If ofd.ShowDialog() = DialogResult.OK Then
                txtFile.Text = ofd.FileName

                Using Stream = File.Open(ofd.FileName, FileMode.Open, FileAccess.Read)
                    Using Reader As IExcelDataReader = ExcelReaderFactory.CreateReader(Stream)
                        Dim result As DataSet = Reader.AsDataSet(New ExcelDataSetConfiguration() With {.ConfigureDataTable = Function(__) New ExcelDataTableConfiguration() With {.UseHeaderRow = True}})

                        tables = result.Tables
                        cbSheet.Items.Clear()
                        For Each table As DataTable In tables
                            cbSheet.Items.Add(table.TableName)
                        Next
                    End Using
                End Using
            End If
        End Using
    End Sub

    Private Sub cbSheet_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbSheet.SelectedIndexChanged
        Dim dt As DataTable = tables(cbSheet.SelectedItem.ToString())
        DataGridView1.DataSource = dt
    End Sub
End Class