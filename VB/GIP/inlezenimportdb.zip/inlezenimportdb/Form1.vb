﻿Imports System.IO
Imports ExcelDataReader
Imports MySql.Data.MySqlClient

Public Class Form1
    Public tables As DataTableCollection
    Private lijststeward As New List(Of steward)
    Private lijsttijd As New List(Of tijd)
    Private lijstplaats As New List(Of plaats)
    Public plaatsen As New plaats
    Public stewards As New steward
    Public tijden As New tijd
    Public conn As MySqlConnection
    Public connstring As String = "server=localhost;Port=3307;database=festivalstewards;uid=root;password=usbw;"
    Private Sub SluitenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SluitenToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub ImportDBToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ImportDBToolStripMenuItem.Click
        Dim result As DialogResult = MessageBox.Show("Wilt u verder gaan?", "Importeren van data", MessageBoxButtons.YesNoCancel)

        If result = DialogResult.Yes Then
            import()
        End If
    End Sub

    Private Sub btnBrows_Click(sender As Object, e As EventArgs) Handles btnBrows.Click
        Using ofd As OpenFileDialog = New OpenFileDialog() 'With {.Filter = "Excel 97-2003 Workbook|*.xls|Excel Workbook|*.xlsx"}

            If ofd.ShowDialog() = DialogResult.OK Then
                txtFile.Text = ofd.FileName

                Using Stream = File.Open(ofd.FileName, FileMode.Open, FileAccess.Read)
                    Using Reader As IExcelDataReader = ExcelReaderFactory.CreateReader(Stream)
                        Dim result As DataSet = Reader.AsDataSet(New ExcelDataSetConfiguration() With {.ConfigureDataTable = Function(__) New ExcelDataTableConfiguration() With {.UseHeaderRow = True}})

                        tables = result.Tables
                        cbSheet.Items.Clear()
                        For Each table As DataTable In tables
                            cbSheet.Items.Add(table.TableName)
                        Next
                    End Using
                End Using
            End If
        End Using
    End Sub

    Private Sub cbSheet_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbSheet.SelectedIndexChanged
        show()
    End Sub

    Public Sub import()
        'Stewards
        Try
            lijststeward = TryCast(DataGridView1.DataSource, List(Of steward))
            If lijststeward IsNot Nothing Then
                stewards.Add()
                MessageBox.Show("geïmporteerd", "einde", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        'plaats


        'tijd


    End Sub

    Private Sub showall()
        'stewards
        Dim dt As DataTable = tables(cbSheet.SelectedItem.ToString())

        If dt IsNot Nothing Then
            For i As Integer = 0 To dt.Rows.Count - 1
                stewards.Naam = dt.Rows(i)("Naam").ToString()
                stewards.Voornaam = dt.Rows(i)("Voornaam").ToString()
                stewards.Telefoonnummer = dt.Rows(i)("gsm").ToString()

                lijststeward.Add(stewards)
            Next
            DataGridView1.DataSource = lijststeward
        End If

        'plaats
        Dim dt2 As DataTable = tables(cbSheet.SelectedItem.ToString())

        If dt2 IsNot Nothing Then
            For i As Integer = 0 To dt.Rows.Count - 1
                plaatsen.afkorting = dt.Rows(i)("afkorting").ToString()


                lijstplaats.Add(plaatsen)
            Next
            DataGridView1.DataSource = lijstplaats
        End If

        'tijd
        Dim dt3 As DataTable = tables(cbSheet.SelectedItem.ToString())

        If dt3 IsNot Nothing Then
            For i As Integer = 0 To dt.Rows.Count - 1
                tijden.Tijd = dt.Rows(i)("tijd").ToString()
                tijden.dag = dt.Rows(i)("dag").ToString()

                lijsttijd.Add(tijden)
            Next
            DataGridView1.DataSource = lijsttijd
        End If
    End Sub
End Class