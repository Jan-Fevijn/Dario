﻿Public Class stewards
    Private _voornaam As String
    Private _telenmr As String
    Private _naam As String

    Public Sub New(voornaam As String, telenmr As String, naam As String)
        _voornaam = voornaam
        _naam = naam
        _telenmr = telenmr
    End Sub

    Public Property Voornaam() As String
        Get
            Return _voornaam
        End Get
        Set(ByVal value As String)
            _voornaam = value
        End Set
    End Property

    Public Property naam() As String
        Get
            Return _naam
        End Get
        Set(ByVal value As String)
            _naam = value
        End Set
    End Property

    Public Property telenmr() As String
        Get
            Return _telenmr
        End Get
        Set(ByVal value As String)
            _telenmr = value
        End Set
    End Property
End Class
