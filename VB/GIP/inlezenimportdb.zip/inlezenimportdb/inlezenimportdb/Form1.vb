﻿Imports System.IO
Imports MySql.Data.MySqlClient

Public Class Form1
    Private split() As String
    Private lijstStewards As List(Of stewards)
    Public conn As MySqlConnection
    Public connstring As String = "server=localhost;Port=3307;database=festivalstewards;uid=root;password=usbw;"
    Private Sub SluitenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SluitenToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub InlezenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InlezenToolStripMenuItem.Click
        With OpenFileDialog1
            .InitialDirectory = "C:\txt"
        End With

        If (OpenFileDialog1.ShowDialog = DialogResult.OK) Then

            FileOpen(1, OpenFileDialog1.FileName, OpenMode.Input)

            Do While Not EOF(1)
                Dim lijn = LineInput(1)
                split = split(lijn, ",")
                lijstStewards.Add(New stewards(split(0), split(1), split(2)))
            Loop

            FileClose(1)
        End If
    End Sub

    Private Sub ImportDBToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ImportDBToolStripMenuItem.Click

    End Sub
End Class
