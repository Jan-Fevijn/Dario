﻿Imports MySql.Data.MySqlClient
Public Class plaats

    Private connStr As String = " server=localhost;user=root;port=3307;password=usbw;database=festivalstewards;"
    Private conn As New MySqlConnection(connStr)
    Private _afkorting As String
    Private _idPlaats As Integer
    Private _plaatsnaam As String
    Public Sub New()
    End Sub
    Public Sub New(afkorting As String, idPlaats As Integer, plaatsnaam As String)
        Me.afkorting = afkorting
        Me.idPlaats = idPlaats
        Me.plaatsnaam = plaatsnaam
    End Sub
    Public Property afkorting() As String
        Get
            Return _afkorting
        End Get
        Set(ByVal value As String)
            _afkorting = value
        End Set
    End Property
    Public Property idPlaats() As Integer
        Get
            Return _idPlaats
        End Get
        Set(ByVal value As Integer)
            _idPlaats = value
        End Set
    End Property
    Public Property plaatsnaam() As String
        Get
            Return _plaatsnaam
        End Get
        Set(ByVal value As String)
            _plaatsnaam = value
        End Set
    End Property
    Public Sub Add()
        Using conn = New MySqlConnection(connStr)
            Dim query = "INSERT INTO plaats(afkorting,idPlaats,plaatsnaam) VALUES(@afkorting,@idPlaats,@plaatsnaam)"
            conn.Open()
            Try
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@afkorting", afkorting())
                    cmd.Parameters.AddWithValue("@idPlaats", idPlaats())
                    cmd.Parameters.AddWithValue("@plaatsnaam", plaatsnaam())
                    cmd.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
            conn.Close()
        End Using
    End Sub
    Public Sub Update()
        Using Conn = New MySqlConnection(connStr)
            Dim query As String = "Update plaats SET afkorting=@afkorting,plaatsnaam=@plaatsnaam WHERE idPlaats = @idPlaats"
            Conn.Open()
            Try
                Using cmd As New MySqlCommand(query, Conn)
                    cmd.Parameters.AddWithValue("@afkorting", afkorting())
                    cmd.Parameters.AddWithValue("@idPlaats", idPlaats())
                    cmd.Parameters.AddWithValue("@plaatsnaam", plaatsnaam())
                    cmd.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
            Conn.Close()
        End Using
    End Sub
    Public Shared Function GetOne(ByVal ID As Integer) As plaats
        Dim myObj As New plaats()
        Using conn = New MySqlConnection(" server=localhost;user=root;port=3307;password=usbw;database=festivalstewards;")
            Dim query As String = "SELECT * FROM plaats WHERE idPlaats = @idPlaats"
            conn.Open()
            Try
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@idPlaats", ID)
                    Using reader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                        If reader.Read() Then
                            myObj.afkorting = reader("afkorting").ToString()
                            myObj.idPlaats = Convert.ToInt32(reader("idPlaats"))
                            myObj.plaatsnaam = reader("plaatsnaam").ToString()
                        End If
                    End Using
                End Using
                Return myObj
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
        End Using
    End Function
    Public Shared Function GetAll() As DataTable
        Using conn = New MySqlConnection(" server=localhost;user=root;port=3307;password=usbw;database=festivalstewards;")
            conn.Open()
            Dim datatable As New DataTable()
            Dim query As String = "SELECT * FROM plaats"
            Try
                Using cmd = New MySqlCommand(query, conn)
                    Using reader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                        datatable.Load(reader)
                    End Using
                    Return datatable
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
        End Using
    End Function
End Class
