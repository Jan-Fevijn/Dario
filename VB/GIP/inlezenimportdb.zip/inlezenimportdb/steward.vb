﻿Imports MySql.Data.MySqlClient
Public Class steward

    Private connStr As String = " server=localhost;user=root;port=3307;password=usbw;database=festivalstewards;"
    Private conn As New MySqlConnection(connStr)
    Private _email As String
    Private _idSteward As Integer
    Private _Naam As String
    Private _Telefoonnummer As String
    Private _User_TypeID As Integer
    Private _Voornaam As String
    Private _Wachtwoord As String
    Private _wwResetCode As String
    Public Sub New()
    End Sub
    Public Sub New(email As String, idSteward As Integer, Naam As String, Telefoonnummer As String, User_TypeID As Integer, Voornaam As String, Wachtwoord As String, wwResetCode As String)
        Me.email = email
        Me.idSteward = idSteward
        Me.Naam = Naam
        Me.Telefoonnummer = Telefoonnummer
        Me.User_TypeID = User_TypeID
        Me.Voornaam = Voornaam
        Me.Wachtwoord = Wachtwoord
        Me.wwResetCode = wwResetCode
    End Sub
    Public Property email() As String
        Get
            Return _email
        End Get
        Set(ByVal value As String)
            _email = value
        End Set
    End Property
    Public Property idSteward() As Integer
        Get
            Return _idSteward
        End Get
        Set(ByVal value As Integer)
            _idSteward = value
        End Set
    End Property
    Public Property Naam() As String
        Get
            Return _Naam
        End Get
        Set(ByVal value As String)
            _Naam = value
        End Set
    End Property
    Public Property Telefoonnummer() As String
        Get
            Return _Telefoonnummer
        End Get
        Set(ByVal value As String)
            _Telefoonnummer = value
        End Set
    End Property
    Public Property User_TypeID() As Integer
        Get
            Return _User_TypeID
        End Get
        Set(ByVal value As Integer)
            _User_TypeID = value
        End Set
    End Property
    Public Property Voornaam() As String
        Get
            Return _Voornaam
        End Get
        Set(ByVal value As String)
            _Voornaam = value
        End Set
    End Property
    Public Property Wachtwoord() As String
        Get
            Return _Wachtwoord
        End Get
        Set(ByVal value As String)
            _Wachtwoord = value
        End Set
    End Property
    Public Property wwResetCode() As String
        Get
            Return _wwResetCode
        End Get
        Set(ByVal value As String)
            _wwResetCode = value
        End Set
    End Property
    Public Sub Add()
        Using conn = New MySqlConnection(connStr)
            Dim query = "INSERT INTO steward(email,idSteward,Naam,Telefoonnummer,User_TypeID,Voornaam,Wachtwoord,wwResetCode) VALUES(@email,@idSteward,@Naam,@Telefoonnummer,@User_TypeID,@Voornaam,@Wachtwoord,@wwResetCode)"
            conn.Open()
            Try
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@email", email())
                    cmd.Parameters.AddWithValue("@idSteward", idSteward())
                    cmd.Parameters.AddWithValue("@Naam", Naam())
                    cmd.Parameters.AddWithValue("@Telefoonnummer", Telefoonnummer())
                    cmd.Parameters.AddWithValue("@User_TypeID", User_TypeID())
                    cmd.Parameters.AddWithValue("@Voornaam", Voornaam())
                    cmd.Parameters.AddWithValue("@Wachtwoord", Wachtwoord())
                    cmd.Parameters.AddWithValue("@wwResetCode", wwResetCode())
                    cmd.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
            conn.Close()
        End Using
    End Sub
    Public Sub Update()
        Using Conn = New MySqlConnection(connStr)
            Dim query As String = "Update steward SET email=@email,Naam=@Naam,Telefoonnummer=@Telefoonnummer,User_TypeID=@User_TypeID,Voornaam=@Voornaam,Wachtwoord=@Wachtwoord,wwResetCode=@wwResetCode WHERE idSteward = @idSteward"
            Conn.Open()
            Try
                Using cmd As New MySqlCommand(query, Conn)
                    cmd.Parameters.AddWithValue("@email", email())
                    cmd.Parameters.AddWithValue("@idSteward", idSteward())
                    cmd.Parameters.AddWithValue("@Naam", Naam())
                    cmd.Parameters.AddWithValue("@Telefoonnummer", Telefoonnummer())
                    cmd.Parameters.AddWithValue("@User_TypeID", User_TypeID())
                    cmd.Parameters.AddWithValue("@Voornaam", Voornaam())
                    cmd.Parameters.AddWithValue("@Wachtwoord", Wachtwoord())
                    cmd.Parameters.AddWithValue("@wwResetCode", wwResetCode())
                    cmd.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
            Conn.Close()
        End Using
    End Sub
    Public Shared Function GetOne(ByVal ID As Integer) As steward
        Dim myObj As New steward()
        Using conn = New MySqlConnection(" server=localhost;user=root;port=3307;password=usbw;database=festivalstewards;")
            Dim query As String = "SELECT * FROM steward WHERE idSteward = @idSteward"
            conn.Open()
            Try
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@idSteward", ID)
                    Using reader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                        If reader.Read() Then
                            myObj.email = reader("email").ToString()
                            myObj.idSteward = Convert.ToInt32(reader("idSteward"))
                            myObj.Naam = reader("Naam").ToString()
                            myObj.Telefoonnummer = reader("Telefoonnummer").ToString()
                            myObj.User_TypeID = Convert.ToInt32(reader("User_TypeID"))
                            myObj.Voornaam = reader("Voornaam").ToString()
                            myObj.Wachtwoord = reader("Wachtwoord").ToString()
                            myObj.wwResetCode = reader("wwResetCode").ToString()
                        End If
                    End Using
                End Using
                Return myObj
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
        End Using
    End Function
    Public Shared Function GetAll() As DataTable
        Using conn = New MySqlConnection(" server=localhost;user=root;port=3307;password=usbw;database=festivalstewards;")
            conn.Open()
            Dim datatable As New DataTable()
            Dim query As String = "SELECT * FROM steward"
            Try
                Using cmd = New MySqlCommand(query, conn)
                    Using reader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                        datatable.Load(reader)
                    End Using
                    Return datatable
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
        End Using
    End Function
End Class
