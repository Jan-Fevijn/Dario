﻿Imports MySql.Data.MySqlClient
Public Class tijd

    Private connStr As String = " server=localhost;user=root;port=3307;password=usbw;database=festivalstewards;"
    Private conn As New MySqlConnection(connStr)
    Private _dag As String
    Private _idTijd As Integer
    Private _Tijd As String
    Public Sub New()
    End Sub
    Public Sub New(dag As String, idTijd As Integer, Tijd As String)
        Me.dag = dag
        Me.idTijd = idTijd
        Me.Tijd = Tijd
    End Sub
    Public Property dag() As String
        Get
            Return _dag
        End Get
        Set(ByVal value As String)
            _dag = value
        End Set
    End Property
    Public Property idTijd() As Integer
        Get
            Return _idTijd
        End Get
        Set(ByVal value As Integer)
            _idTijd = value
        End Set
    End Property
    Public Property Tijd() As String
        Get
            Return _Tijd
        End Get
        Set(ByVal value As String)
            _Tijd = value
        End Set
    End Property
    Public Sub Add()
        Using conn = New MySqlConnection(connStr)
            Dim query = "INSERT INTO tijd(dag,idTijd,Tijd) VALUES(@dag,@idTijd,@Tijd)"
            conn.Open()
            Try
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@dag", dag())
                    cmd.Parameters.AddWithValue("@idTijd", idTijd())
                    cmd.Parameters.AddWithValue("@Tijd", Tijd())
                    cmd.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
            conn.Close()
        End Using
    End Sub
    Public Sub Update()
        Using Conn = New MySqlConnection(connStr)
            Dim query As String = "Update tijd SET dag=@dag,Tijd=@Tijd WHERE idTijd = @idTijd"
            Conn.Open()
            Try
                Using cmd As New MySqlCommand(query, Conn)
                    cmd.Parameters.AddWithValue("@dag", dag())
                    cmd.Parameters.AddWithValue("@idTijd", idTijd())
                    cmd.Parameters.AddWithValue("@Tijd", Tijd())
                    cmd.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
            Conn.Close()
        End Using
    End Sub
    Public Shared Function GetOne(ByVal ID As Integer) As tijd
        Dim myObj As New tijd()
        Using conn = New MySqlConnection(" server=localhost;user=root;port=3307;password=usbw;database=festivalstewards;")
            Dim query As String = "SELECT * FROM tijd WHERE idTijd = @idTijd"
            conn.Open()
            Try
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@idTijd", ID)
                    Using reader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                        If reader.Read() Then
                            myObj.dag = reader("dag").ToString()
                            myObj.idTijd = Convert.ToInt32(reader("idTijd"))
                            myObj.Tijd = reader("Tijd").ToString()
                        End If
                    End Using
                End Using
                Return myObj
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
        End Using
    End Function
    Public Shared Function GetAll() As DataTable
        Using conn = New MySqlConnection(" server=localhost;user=root;port=3307;password=usbw;database=festivalstewards;")
            conn.Open()
            Dim datatable As New DataTable()
            Dim query As String = "SELECT * FROM tijd"
            Try
                Using cmd = New MySqlCommand(query, conn)
                    Using reader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                        datatable.Load(reader)
                    End Using
                    Return datatable
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
        End Using
    End Function
End Class
