﻿Imports MySql.Data.MySqlClient
Imports System.IO

Public Class Form1
    Public dt As New DataTable
    Public dtBackup As New DataTable
    'databanken
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dt = Persoon.GetAll(5, 5)
        dtBackup = Persoon.GetAll(5, 5)

        DataGridView1.DataSource = dt
        werdaangepast()
    End Sub

    'Alle buttons/clicks
    Private Sub SluitenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SluitenToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub btnIO_Click(sender As Object, e As EventArgs) Handles btnIO.Click
        Dim p As New Persoon
        p.Naam = txtIO.Text
        p.Voornaam = txtBedragIO.Text
        p.Wachtwoord = txtww.Text
        p.Add()
        werdaangepast()
    End Sub

    'Dit was export die niet gelukt is maar niet weg wou doen, er is niet aangepast omdat ik niets vond 
    '!!!!

    'Private Sub ExportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExportToolStripMenuItem.Click
    '    BestandOpslaan("", BrowseFolder())
    'End Sub

    ''subs en functions
    'Public Sub BestandOpslaan(ByVal path As String)
    '    Dim file As StreamWriter
    '    file = My.Computer.FileSystem.OpenTextFileWriter(path + "\bank.txt", False)

    '    Using file
    '        For row As Integer = 0 To dt.RowCount - 1
    '            For col As Integer = 0 To dt.ColumnCount - 1
    '                '               file.WriteLine(dt.Rows(row).Cells(col).Value.ToString)
    '            Next
    '        Next
    '    End Using

    '    file.Close()
    'End Sub

    'Private Function BrowseFolder() As String
    '    If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
    '        Return FolderBrowserDialog1.SelectedPath
    '    Else
    '        Return “no-path”
    '    End If
    'End Function
    Private Sub werdaangepast()
        For i = 0 To dt.Rows.Count - 1

            If dt.Rows(i).RowState <> DataRowState.Unchanged Then
                Select Case dt.Rows(i).RowState
                    Case 4
                        Dim p As New Persoon()
                        p.Naam = dt.Rows(i).Item("Naam")
                        p.Voornaam = dt.Rows(i).Item("Voornaam")
                        p.Wachtwoord = dt.Rows(i).Item("wachtwoord")
                        p.Add()
                    Case 8
                        MessageBox.Show("werd gewist")
                        Persoon.Delete(dtBackup.Rows(i).Item("IDPersoon"))
                    Case 16
                        Dim p = Persoon.GetOne(dt.Rows(i).Item("IDPersoon"))
                        p.Naam = dt.Rows(i).Item("Naam")
                        p.Voornaam = dt.Rows(i).Item("Voornaam")
                        p.Wachtwoord = dt.Rows(i).Item("wachtwoord")
                        p.Update()
                End Select
            End If
        Next
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim p As New Persoon
        p.Naam = txtNaamins.Text
        p.Voornaam = txtvrNaamins.Text
        p.Wachtwoord = txtwahtwoord.Text
        p.IDPersoon = txtid.Text
        p.Update()
        werdaangepast()
    End Sub
End Class
