﻿Imports MySql.Data.MySqlClient

Public Class Form1
    Public connstring As String = "server=localhost;Port=3307;database=diepvries;uid=root;password=usbw;"
    Public conn As New MySqlConnection(connstring)
    Private ladeinhoud As New inhoudlade
    Private lades As New DataTable
    Private prod As New DataTable
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillcombo()
        filldatagrid()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        delete()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        add()
    End Sub

    Sub fillcombo()

        lades = lade.GetAll()
        prod = inhoud.GetAll()

        cbLade.DataSource = lades
        cbLade.ValueMember = "idlade"
        cbLade.DisplayMember = "lade"

        cbProd.DataSource = prod
        cbProd.ValueMember = "idinhoud"
        cbProd.DisplayMember = "type"

        cbDellade.DataSource = lades
        cbDellade.ValueMember = "idlade"
        cbDellade.DisplayMember = "lade"

        cbDelProd.DataSource = prod
        cbDelProd.ValueMember = "idinhoud"
        cbDelProd.DisplayMember = "type"

        cbShow.DataSource = lades
        cbShow.ValueMember = "idlade"
        cbShow.DisplayMember = "lade"
    End Sub

    Sub filldatagrid()
        lades = lade.GetAll()

        cbShow.DataSource = lades
        cbShow.ValueMember = "idlade"
        cbShow.DisplayMember = "lade"

        Dim info As DataTable

        info = inhoudlade.GetAllinfo(cbShow.SelectedValue)

        dgvLade1.DataSource = info

        dgvLade1.Refresh()
    End Sub

    Sub delete()
        ladeinhoud.lade = cbDellade.SelectedValue
        ladeinhoud.inhoud = cbDelProd.SelectedValue
        ladeinhoud.delete()

        MessageBox.Show("verwijderd uit diepvries")
    End Sub

    Sub add()
        ladeinhoud.inhoud = cbProd.SelectedValue
        ladeinhoud.lade = cbLade.SelectedValue
        ladeinhoud.Add()

        MessageBox.Show("toegevoegd in diepvries")
    End Sub

    Private Sub NieuwProductToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NieuwProductToolStripMenuItem.Click
        NieuwProd.Show()
    End Sub
End Class