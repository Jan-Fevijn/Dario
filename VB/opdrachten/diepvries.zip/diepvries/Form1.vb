﻿Imports MySql.Data.MySqlClient

Public Class Form1
    Public connstring As String = "server=localhost;Port=3307;database=diepvries;uid=root;password=usbw;"
    Public conn As New MySqlConnection(connstring)
    Private ladeinhoud As New inhoudlade
    Private diepvries As New DataTable
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fill()
    End Sub

    Sub fill()
        diepvries = inhoudlade.GetAllinfo()

        dgLades.DataSource = diepvries
    End Sub


    Sub delete()
        Dim verwijderen As DataTable = diepvries.GetChanges

        If Not IsNothing(verwijderen) AndAlso verwijderen.Rows.Count > 0 Then
            For Each row As DataRow In verwijderen.Rows
                ladeinhoud = inhoudlade.GetOne(row("idhoudbaarheid"))
                Dim producten As inhoud = inhoud.GetOne(row("idinhoud"))
                ladeinhoud.invriesdatum = row("invriesdatum")
                Dim laden As lade = lade.GetOne(row("idlade"))
                ladeinhoud.inhoud = producten
                ladeinhoud.lade = laden

                ladeinhoud.delete()
                MessageBox.Show("verwijderd uit lade")
            Next
        End If
    End Sub

    Sub add()
        Dim toevoegen As DataTable = diepvries.GetChanges

        If Not IsNothing(toevoegen) AndAlso toevoegen.Rows.Count > 0 Then
            For Each row As DataRow In toevoegen.Rows
                ladeinhoud = inhoudlade.GetOne(row("idhoudbaarheid"))
                Dim producten As inhoud = inhoud.GetOne(row("idinhoud"))
                ladeinhoud.invriesdatum = row("invriesdatum")
                Dim laden As lade = lade.GetOne(row("idlade"))
                ladeinhoud.inhoud = producten
                ladeinhoud.lade = laden

                ladeinhoud.Add()
                MessageBox.Show("toegevoegd in lade")
            Next
        End If
    End Sub

    Sub updatedg()
        Dim updaten As DataTable = diepvries.GetChanges

        If Not IsNothing(updaten) AndAlso updaten.Rows.Count > 0 Then
            For Each row As DataRow In updaten.Rows
                ladeinhoud = inhoudlade.GetOne(row("idhoudbaarheid"))
                Dim producten As inhoud = inhoud.GetOne(row("idinhoud"))
                ladeinhoud.invriesdatum = row("invriesdatum")
                Dim laden As lade = lade.GetOne(row("idlade"))
                ladeinhoud.inhoud = producten
                ladeinhoud.lade = laden

                ladeinhoud.Update()
                MessageBox.Show("geupdate in lade")
            Next
        End If
    End Sub

    Private Sub NieuwProductToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NieuwProductToolStripMenuItem.Click
        NieuwProd.Show()
    End Sub

    Private Sub btnAdd_Click_1(sender As Object, e As EventArgs) Handles btnAdd.Click
        add()
    End Sub

    Private Sub btnVerwijderen_Click(sender As Object, e As EventArgs) Handles btnVerwijderen.Click
        delete()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        updatedg()
    End Sub
End Class