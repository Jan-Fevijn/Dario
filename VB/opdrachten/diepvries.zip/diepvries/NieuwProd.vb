﻿Imports MySql.Data.MySqlClient
Public Class NieuwProd
    Private prod As New inhoud
    Private Sub btnaddprod_Click(sender As Object, e As EventArgs) Handles btnaddprod.Click
        prod.type = txtprod.Text
        prod.houdbaarheidsdatum = DateTimePicker1.Value
        prod.Add()

        MessageBox.Show("product toegevoegd")
        txtprod.Clear()
        DateTimePicker1.Refresh()
    End Sub

    Private Sub DiepvriesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DiepvriesToolStripMenuItem.Click
        Form1.Show()
    End Sub
End Class