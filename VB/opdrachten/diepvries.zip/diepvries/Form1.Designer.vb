﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.dgvLade1 = New System.Windows.Forms.DataGridView()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbProd = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cbLade = New System.Windows.Forms.ComboBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.NieuwProductToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.cbShow = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cbDelProd = New System.Windows.Forms.ComboBox()
        Me.cbDellade = New System.Windows.Forms.ComboBox()
        CType(Me.dgvLade1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgvLade1
        '
        Me.dgvLade1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLade1.Location = New System.Drawing.Point(237, 111)
        Me.dgvLade1.Name = "dgvLade1"
        Me.dgvLade1.RowHeadersWidth = 51
        Me.dgvLade1.RowTemplate.Height = 24
        Me.dgvLade1.Size = New System.Drawing.Size(347, 117)
        Me.dgvLade1.TabIndex = 1
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(49, 111)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 7
        Me.btnAdd.Text = "add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(49, 223)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(75, 23)
        Me.btnDelete.TabIndex = 8
        Me.btnDelete.Text = "delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 17)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "product:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 149)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 17)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "product:"
        '
        'cbProd
        '
        Me.cbProd.FormattingEnabled = True
        Me.cbProd.Location = New System.Drawing.Point(84, 30)
        Me.cbProd.Name = "cbProd"
        Me.cbProd.Size = New System.Drawing.Size(100, 24)
        Me.cbProd.TabIndex = 13
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(15, 76)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 17)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "lade:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(15, 186)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 17)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "lade:"
        '
        'cbLade
        '
        Me.cbLade.FormattingEnabled = True
        Me.cbLade.Location = New System.Drawing.Point(84, 69)
        Me.cbLade.Name = "cbLade"
        Me.cbLade.Size = New System.Drawing.Size(100, 24)
        Me.cbLade.TabIndex = 18
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NieuwProductToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(596, 28)
        Me.MenuStrip1.TabIndex = 19
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'NieuwProductToolStripMenuItem
        '
        Me.NieuwProductToolStripMenuItem.Name = "NieuwProductToolStripMenuItem"
        Me.NieuwProductToolStripMenuItem.Size = New System.Drawing.Size(121, 24)
        Me.NieuwProductToolStripMenuItem.Text = "Nieuw product"
        '
        'cbShow
        '
        Me.cbShow.FormattingEnabled = True
        Me.cbShow.Location = New System.Drawing.Point(393, 69)
        Me.cbShow.Name = "cbShow"
        Me.cbShow.Size = New System.Drawing.Size(121, 24)
        Me.cbShow.TabIndex = 20
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(298, 72)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 17)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Toon lade:"
        '
        'cbDelProd
        '
        Me.cbDelProd.FormattingEnabled = True
        Me.cbDelProd.Location = New System.Drawing.Point(84, 149)
        Me.cbDelProd.Name = "cbDelProd"
        Me.cbDelProd.Size = New System.Drawing.Size(121, 24)
        Me.cbDelProd.TabIndex = 22
        '
        'cbDellade
        '
        Me.cbDellade.FormattingEnabled = True
        Me.cbDellade.Location = New System.Drawing.Point(84, 191)
        Me.cbDellade.Name = "cbDellade"
        Me.cbDellade.Size = New System.Drawing.Size(121, 24)
        Me.cbDellade.TabIndex = 23
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(596, 276)
        Me.Controls.Add(Me.cbDellade)
        Me.Controls.Add(Me.cbDelProd)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.cbShow)
        Me.Controls.Add(Me.cbLade)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cbProd)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.dgvLade1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "diepvries"
        CType(Me.dgvLade1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvLade1 As DataGridView
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cbProd As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents cbLade As ComboBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents NieuwProductToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents cbShow As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents cbDelProd As ComboBox
    Friend WithEvents cbDellade As ComboBox
End Class
