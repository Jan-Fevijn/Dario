﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.dgLades = New System.Windows.Forms.DataGridView()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.NieuwProductToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnVerwijderen = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.txtverwijderen = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.dgLades, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgLades
        '
        Me.dgLades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLades.Location = New System.Drawing.Point(71, 115)
        Me.dgLades.Name = "dgLades"
        Me.dgLades.RowHeadersWidth = 51
        Me.dgLades.RowTemplate.Height = 24
        Me.dgLades.Size = New System.Drawing.Size(457, 149)
        Me.dgLades.TabIndex = 1
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NieuwProductToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(596, 28)
        Me.MenuStrip1.TabIndex = 19
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'NieuwProductToolStripMenuItem
        '
        Me.NieuwProductToolStripMenuItem.Name = "NieuwProductToolStripMenuItem"
        Me.NieuwProductToolStripMenuItem.Size = New System.Drawing.Size(121, 24)
        Me.NieuwProductToolStripMenuItem.Text = "Nieuw product"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(68, 69)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(256, 17)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Toevoegen of verwijderen uit diepvries:"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(363, 69)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 22
        Me.btnAdd.Text = "add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnVerwijderen
        '
        Me.btnVerwijderen.Location = New System.Drawing.Point(419, 313)
        Me.btnVerwijderen.Name = "btnVerwijderen"
        Me.btnVerwijderen.Size = New System.Drawing.Size(94, 23)
        Me.btnVerwijderen.TabIndex = 23
        Me.btnVerwijderen.Text = "Verwijderen"
        Me.btnVerwijderen.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(453, 69)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(75, 23)
        Me.btnUpdate.TabIndex = 24
        Me.btnUpdate.Text = "update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'txtverwijderen
        '
        Me.txtverwijderen.Location = New System.Drawing.Point(295, 316)
        Me.txtverwijderen.Name = "txtverwijderen"
        Me.txtverwijderen.Size = New System.Drawing.Size(100, 22)
        Me.txtverwijderen.TabIndex = 25
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(168, 319)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(111, 17)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "idhoudbaarheid:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(596, 370)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtverwijderen)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnVerwijderen)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.dgLades)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "diepvries"
        CType(Me.dgLades, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgLades As DataGridView
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents NieuwProductToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label5 As Label
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnVerwijderen As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents txtverwijderen As TextBox
    Friend WithEvents Label1 As Label
End Class
