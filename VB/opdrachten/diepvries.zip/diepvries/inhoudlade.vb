﻿Imports MySql.Data.MySqlClient
Public Class inhoudlade

    Private connStr As String = "server=localhost;user=root;port=3307;password=usbw;database=diepvries;"
    Private conn As New MySqlConnection(connStr)
    Private _aantal As String
    Private _gewicht As Integer
    Private _idhoudbaarheid As Integer
    Private _inhoud As inhoud
    Private _invriesdatum As Date
    Private _lade As lade
    Public Sub New()
    End Sub
    Public Sub New(aantal As String, gewicht As Integer, idhoudbaarheid As Integer, inhoud As inhoud, invriesdatum As Date, lade As lade)
        Me.aantal = aantal
        Me.gewicht = gewicht
        Me.idhoudbaarheid = idhoudbaarheid
        Me.inhoud = inhoud
        Me.invriesdatum = invriesdatum
        Me.lade = lade
    End Sub
    Public Property aantal() As String
        Get
            Return _aantal
        End Get
        Set(ByVal value As String)
            _aantal = value
        End Set
    End Property
    Public Property gewicht() As Integer
        Get
            Return _gewicht
        End Get
        Set(ByVal value As Integer)
            _gewicht = value
        End Set
    End Property
    Public Property idhoudbaarheid() As Integer
        Get
            Return _idhoudbaarheid
        End Get
        Set(ByVal value As Integer)
            _idhoudbaarheid = value
        End Set
    End Property
    Public Property inhoud() As inhoud
        Get
            Return _inhoud
        End Get
        Set(ByVal value As inhoud)
            _inhoud = value
        End Set
    End Property
    Public Property invriesdatum() As Date
        Get
            Return _invriesdatum
        End Get
        Set(ByVal value As Date)
            _invriesdatum = value
        End Set
    End Property
    Public Property lade() As lade
        Get
            Return _lade
        End Get
        Set(ByVal value As lade)
            _lade = value
        End Set
    End Property
    Public Sub Add()
        Using conn = New MySqlConnection(connStr)
            Dim query = "INSERT INTO inhoudlade(aantal,gewicht,idhoudbaarheid,inhoud,invriesdatum,lade) VALUES(@aantal,@gewicht,@idhoudbaarheid,@inhoud,@invriesdatum,@lade)"
            conn.Open()
            Try
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@aantal", aantal())
                    cmd.Parameters.AddWithValue("@gewicht", gewicht())
                    cmd.Parameters.AddWithValue("@idhoudbaarheid", idhoudbaarheid())
                    cmd.Parameters.AddWithValue("@inhoud", inhoud.idinhoud)
                    cmd.Parameters.AddWithValue("@invriesdatum", invriesdatum())
                    cmd.Parameters.AddWithValue("@lade", lade.idlade)
                    cmd.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
            conn.Close()
        End Using
    End Sub
    Public Sub Update()
        Using Conn = New MySqlConnection(connStr)
            Dim query As String = "Update inhoudlade SET aantal=@aantal,gewicht=@gewicht,inhoud=@inhoud,invriesdatum=@invriesdatum,lade=@lade WHERE idhoudbaarheid = @idhoudbaarheid"
            Conn.Open()
            Try
                Using cmd As New MySqlCommand(query, Conn)
                    cmd.Parameters.AddWithValue("@aantal", aantal())
                    cmd.Parameters.AddWithValue("@gewicht", gewicht())
                    cmd.Parameters.AddWithValue("@idhoudbaarheid", idhoudbaarheid())
                    cmd.Parameters.AddWithValue("@inhoud", inhoud.idinhoud)
                    cmd.Parameters.AddWithValue("@invriesdatum", invriesdatum())
                    cmd.Parameters.AddWithValue("@lade", lade.idlade)
                    cmd.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
            Conn.Close()
        End Using
    End Sub
    Public Shared Function GetOne(ByVal ID As Integer) As inhoudlade
        Dim myObj As New inhoudlade()
        Using conn = New MySqlConnection("server=localhost;user=root;port=3307;password=usbw;database=diepvries;")
            Dim query As String = "SELECT * FROM inhoudlade WHERE idhoudbaarheid = @idhoudbaarheid"
            conn.Open()
            Try
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@idhoudbaarheid", ID)
                    Using reader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                        If reader.Read() Then
                            myObj.aantal = reader("aantal").ToString()
                            myObj.gewicht = Convert.ToInt32(reader("gewicht"))
                            myObj.idhoudbaarheid = Convert.ToInt32(reader("idhoudbaarheid"))
                            myObj.inhoud.idinhoud = Convert.ToInt32(reader("inhoud"))
                            myObj.invriesdatum = reader("invriesdatum").ToString()
                            myObj.lade.idlade = Convert.ToInt32(reader("lade"))
                        End If
                    End Using
                End Using
                Return myObj
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
        End Using
    End Function
    Public Shared Function GetAll() As DataTable
        Using conn = New MySqlConnection("server=localhost;user=root;port=3307;password=usbw;database=diepvries;")
            conn.Open()
            Dim datatable As New DataTable()
            Dim query As String = "SELECT * FROM inhoudlade"
            Try
                Using cmd = New MySqlCommand(query, conn)
                    Using reader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                        datatable.Load(reader)
                    End Using
                    Return datatable
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
        End Using
    End Function

    Public Sub delete()
        Using Conn = New MySqlConnection(connStr)
            Dim query As String = "DELETE * from `inhoudlade` where `inhoud` = @inhoud and `lade` = @lade"
            Conn.Open()
            Try
                Using cmd As New MySqlCommand(query, Conn)
                    cmd.Parameters.AddWithValue("@inhoud", inhoud.idinhoud)
                    cmd.Parameters.AddWithValue("@lade", lade.idlade)
                    cmd.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
            Conn.Close()
        End Using
    End Sub

    Public Shared Function GetAllinfo(ByVal nr) As DataTable
        Using conn = New MySqlConnection("server=localhost;user=root;port=3307;password=usbw;database=diepvries;")
            conn.Open()
            Dim datatable As New DataTable()
            Dim query As String = "SELECT * FROM showall where lade = " & nr
            Try
                Using cmd = New MySqlCommand(query, conn)
                    Using reader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                        datatable.Load(reader)
                    End Using
                    Return datatable
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
        End Using
    End Function
End Class
