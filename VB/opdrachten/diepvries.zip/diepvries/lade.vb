﻿Imports MySql.Data.MySqlClient
Public Class lade

    Private connStr As String = "server=localhost;user=root;port=3307;password=usbw;database=diepvries;"
    Private conn As New MySqlConnection(connStr)
    Private _idlade As Integer
    Private _lade As Integer
    Public Sub New()
    End Sub
    Public Sub New(idlade As Integer, lade As Integer)
        Me.idlade = idlade
        Me.lade = lade
    End Sub
    Public Property idlade() As Integer
        Get
            Return _idlade
        End Get
        Set(ByVal value As Integer)
            _idlade = value
        End Set
    End Property
    Public Property lade() As Integer
        Get
            Return _lade
        End Get
        Set(ByVal value As Integer)
            _lade = value
        End Set
    End Property
    Public Sub Add()
        Using conn = New MySqlConnection(connStr)
            Dim query = "INSERT INTO lade(idlade,lade) VALUES(@idlade,@lade)"
            conn.Open()
            Try
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@idlade", idlade())
                    cmd.Parameters.AddWithValue("@lade", lade())
                    cmd.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
            conn.Close()
        End Using
    End Sub
    Public Sub Update()
        Using Conn = New MySqlConnection(connStr)
            Dim query As String = "Update lade SET lade=@lade WHERE idlade = @idlade"
            Conn.Open()
            Try
                Using cmd As New MySqlCommand(query, Conn)
                    cmd.Parameters.AddWithValue("@idlade", idlade())
                    cmd.Parameters.AddWithValue("@lade", lade())
                    cmd.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
            Conn.Close()
        End Using
    End Sub
    Public Shared Function GetOne(ByVal ID As Integer) As lade
        Dim myObj As New lade()
        Using conn = New MySqlConnection("server=localhost;user=root;port=3307;password=usbw;database=diepvries;")
            Dim query As String = "SELECT * FROM lade WHERE idlade = @idlade"
            conn.Open()
            Try
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@idlade", ID)
                    Using reader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                        If reader.Read() Then
                            myObj.idlade = Convert.ToInt32(reader("idlade"))
                            myObj.lade = Convert.ToInt32(reader("lade"))
                        End If
                    End Using
                End Using
                Return myObj
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
        End Using
    End Function
    Public Shared Function GetAll() As DataTable
        Using conn = New MySqlConnection("server=localhost;user=root;port=3307;password=usbw;database=diepvries;")
            conn.Open()
            Dim datatable As New DataTable()
            Dim query As String = "SELECT * FROM lade"
            Try
                Using cmd = New MySqlCommand(query, conn)
                    Using reader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                        datatable.Load(reader)
                    End Using
                    Return datatable
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
        End Using
    End Function
End Class
