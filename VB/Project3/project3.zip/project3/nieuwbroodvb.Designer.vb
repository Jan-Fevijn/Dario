﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class nieuwbroodvb
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtbrood = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.AutomaatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaldoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NieuwBroodToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(115, 206)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 23)
        Me.btnadd.TabIndex = 0
        Me.btnadd.Text = "add"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(35, 156)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "brood"
        '
        'txtbrood
        '
        Me.txtbrood.Location = New System.Drawing.Point(104, 153)
        Me.txtbrood.Name = "txtbrood"
        Me.txtbrood.Size = New System.Drawing.Size(100, 22)
        Me.txtbrood.TabIndex = 2
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AutomaatToolStripMenuItem, Me.SaldoToolStripMenuItem, Me.NieuwBroodToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(304, 28)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AutomaatToolStripMenuItem
        '
        Me.AutomaatToolStripMenuItem.Name = "AutomaatToolStripMenuItem"
        Me.AutomaatToolStripMenuItem.Size = New System.Drawing.Size(94, 24)
        Me.AutomaatToolStripMenuItem.Text = "toevoegen"
        '
        'SaldoToolStripMenuItem
        '
        Me.SaldoToolStripMenuItem.Name = "SaldoToolStripMenuItem"
        Me.SaldoToolStripMenuItem.Size = New System.Drawing.Size(59, 24)
        Me.SaldoToolStripMenuItem.Text = "saldo"
        '
        'NieuwBroodToolStripMenuItem
        '
        Me.NieuwBroodToolStripMenuItem.Name = "NieuwBroodToolStripMenuItem"
        Me.NieuwBroodToolStripMenuItem.Size = New System.Drawing.Size(107, 24)
        Me.NieuwBroodToolStripMenuItem.Text = "nieuw brood"
        '
        'nieuwbroodvb
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(304, 354)
        Me.Controls.Add(Me.txtbrood)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "nieuwbroodvb"
        Me.Text = "nieuwbroodvb"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnadd As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txtbrood As TextBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents AutomaatToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaldoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NieuwBroodToolStripMenuItem As ToolStripMenuItem
End Class
