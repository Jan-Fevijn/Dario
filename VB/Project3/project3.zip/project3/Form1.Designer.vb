﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmToevoegenBrood
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToevoegenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaldoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.txtbrood = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.nmrcode = New System.Windows.Forms.NumericUpDown()
        Me.nmraantal = New System.Windows.Forms.NumericUpDown()
        Me.nmrprijs = New System.Windows.Forms.NumericUpDown()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.nmrcode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nmraantal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nmrprijs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToevoegenToolStripMenuItem, Me.SaldoToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(423, 28)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToevoegenToolStripMenuItem
        '
        Me.ToevoegenToolStripMenuItem.Name = "ToevoegenToolStripMenuItem"
        Me.ToevoegenToolStripMenuItem.Size = New System.Drawing.Size(96, 24)
        Me.ToevoegenToolStripMenuItem.Text = "Toevoegen"
        '
        'SaldoToolStripMenuItem
        '
        Me.SaldoToolStripMenuItem.Name = "SaldoToolStripMenuItem"
        Me.SaldoToolStripMenuItem.Size = New System.Drawing.Size(59, 24)
        Me.SaldoToolStripMenuItem.Text = "saldo"
        '
        'txtbrood
        '
        Me.txtbrood.Location = New System.Drawing.Point(180, 138)
        Me.txtbrood.Name = "txtbrood"
        Me.txtbrood.Size = New System.Drawing.Size(100, 22)
        Me.txtbrood.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(102, 141)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 17)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "brood"
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(192, 317)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 23)
        Me.btnadd.TabIndex = 7
        Me.btnadd.Text = "add"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(116, 49)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(209, 39)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Nieuw brood"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(102, 176)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 17)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "locatie"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(102, 209)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 17)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "kostprijs"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(102, 250)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 17)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "aantal"
        '
        'nmrcode
        '
        Me.nmrcode.Location = New System.Drawing.Point(180, 174)
        Me.nmrcode.Name = "nmrcode"
        Me.nmrcode.Size = New System.Drawing.Size(100, 22)
        Me.nmrcode.TabIndex = 14
        '
        'nmraantal
        '
        Me.nmraantal.Location = New System.Drawing.Point(180, 245)
        Me.nmraantal.Name = "nmraantal"
        Me.nmraantal.Size = New System.Drawing.Size(100, 22)
        Me.nmraantal.TabIndex = 15
        '
        'nmrprijs
        '
        Me.nmrprijs.DecimalPlaces = 2
        Me.nmrprijs.Location = New System.Drawing.Point(180, 209)
        Me.nmrprijs.Name = "nmrprijs"
        Me.nmrprijs.Size = New System.Drawing.Size(100, 22)
        Me.nmrprijs.TabIndex = 16
        '
        'frmToevoegenBrood
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(423, 418)
        Me.Controls.Add(Me.nmrprijs)
        Me.Controls.Add(Me.nmraantal)
        Me.Controls.Add(Me.nmrcode)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtbrood)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmToevoegenBrood"
        Me.Text = "Brood Toevoegen"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.nmrcode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nmraantal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nmrprijs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ToevoegenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaldoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents txtbrood As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnadd As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents nmrcode As NumericUpDown
    Friend WithEvents nmraantal As NumericUpDown
    Friend WithEvents nmrprijs As NumericUpDown
End Class
