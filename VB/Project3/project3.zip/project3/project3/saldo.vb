﻿Imports MySql.Data.MySqlClient
Imports System.Data.Sql
Imports System
Imports System.Data
Imports System.Data.OleDb
Public Class saldo
    Public conn As MySqlConnection
    Public connstring As String = "server=localhost;Port=3307;database=project3;uid=root;password=usbw; "
    Private Sub ToevoegenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ToevoegenToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim Command As New MySqlCommand("update `saldo` set saldo = @saldo where idklant = @id", conn)

        Command.Parameters.Add("@saldo", MySqlDbType.VarChar).Value = txtSaldo.Text
        Command.Parameters.Add("@id", MySqlDbType.VarChar).Value = txtid.Text

        If Command.ExecuteNonQuery() = 1 Then
            MessageBox.Show("gelukt!")
        Else
            MessageBox.Show("niet gelukt!")
        End If
    End Sub
End Class