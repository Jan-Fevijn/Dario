﻿Imports MySql.Data.MySqlClient
Imports System.Data.Sql
Imports System
Imports System.Data
Imports System.Data.OleDb
Public Class frmToevoegenBrood
    Public conn As MySqlConnection
    Public connstring As String = "server=localhost;Port=3307;database=project3;uid=root;password=usbw; "
    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click

    End Sub
End Class
