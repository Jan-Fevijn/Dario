﻿Public Class nieuwbroodvb
    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        'add brood
        Dim type As String
        type = txtbrood.Text

        Dim Brood As New broodtype()

        Brood.broodnaam = type
        Brood.Add()

        MessageBox.Show("brood is toegevoegd")
        txtbrood.Clear()
    End Sub

    Private Sub SaldoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaldoToolStripMenuItem.Click
        Me.Show()
        balans.Show()
    End Sub

    Private Sub AutomaatToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AutomaatToolStripMenuItem.Click
        Me.Show()
        frmToevoegenBrood.Show()
    End Sub
End Class