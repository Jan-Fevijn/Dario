﻿Imports MySql.Data.MySqlClient
Imports System.Data.Sql
Imports System
Imports System.Data
Imports System.Data.OleDb

Public Class frmToevoegenBrood
    Public todaysdate As Date = String.Format("{0:dd/MM/yyyy}", DateTime.Now)
    'Public x As New MYSQLGenerator.MySqlGenerator("localhost", "root", "usbw", "project3", "3307")
    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Dim brood = txtbrood.Text

        'add in automaat 

        Dim eigenschap As New broodpositiedatum()
        eigenschap.aantalIn = nmraantal.Value
        eigenschap.kostprijs = nmrprijs.Value
        eigenschap.Datum = todaysdate
        eigenschap.positie = nmrcode.Value
        eigenschap.idbrood = broodtype.GetOne(brood)

        eigenschap.Add()

        MessageBox.Show("Het brood is toegevoegd")

    End Sub

    Private Sub SaldoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaldoToolStripMenuItem.Click
        Me.Show()
        balans.Show()
    End Sub

    Private Sub NieuwBroodToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NieuwBroodToolStripMenuItem.Click
        Me.Show()
        nieuwbroodvb.Show()
    End Sub

    Private Sub frmToevoegenBrood_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
