﻿Imports MySql.Data.MySqlClient
Imports System.Data.Sql
Imports System
Imports System.Data
Imports System.Data.OleDb

Public Class frmToevoegenBrood

    Dim todaysdate As String = String.Format("{0:dd/MM/yyyy}", DateTime.Now)
    Dim x As New MYSQLGenerator.MySqlGenerator("localhost", "root", "usbw", "project3", "3307")

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        'hier geprobeerd met de object generator van rubin
        Dim Brood As New broodtype
        Dim eigenschap As New broodpositiedatum
        Brood.broodnaam = txtbrood.Text
        eigenschap.aantalIn = nmrAantal.Value
        eigenschap.kostprijs = nmrPrijs.Value
        eigenschap.Datum = todaysdate
        eigenschap.positie = nmrCode.Value
        Brood.Add()
        eigenschap.Add()

        'hier geprobeerd met de dll van rubin
        Dim naam = txtbrood.Text

        x.Query("insert into broodtype(broodnaam) value(?)", New List(Of Object)({naam}))

        Dim y = x.GetData("select idbroodtype from broodtype where broodnaam = ?", New List(Of Object)({naam}))


        x.Query("insert into broodpositiedatum(idbrood,aantalIn, kostprijs, datum, positie) value(?,?,?,?,?)", New List(Of Object)({y, nmrAantal.Value, nmrPrijs.Value, todaysdate, nmrCode.Value}))

        MessageBox.Show("Het brood is toegevoegd")

    End Sub

    Private Sub SaldoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaldoToolStripMenuItem.Click
        Me.Show()
        balans.Show()
    End Sub
End Class
