﻿Imports MySql.Data.MySqlClient
Imports System.Data.Sql
Imports System
Imports System.Data
Imports System.Data.OleDb

Public Class frmToevoegenBrood
    Public todaysdate As String = String.Format("{0:dd/MM/yyyy}", DateTime.Now)
    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click

        'add brood
        Dim type As String
        type = txtbrood.Text

        Dim Brood As New broodtype()

        Brood.broodnaam = type
        Brood.Add()

        'add in automaat 
        Dim eigenschap As New broodpositiedatum()
        eigenschap.aantalIn = nmraantal.Value
        eigenschap.kostprijs = nmrprijs.Value
        eigenschap.Datum = todaysdate
        eigenschap.positie = nmrcode.Value
        eigenschap.idbrood = broodtype.GetOne(type)

        eigenschap.Add()

        MessageBox.Show("Het brood is toegevoegd")

    End Sub

    Private Sub SaldoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaldoToolStripMenuItem.Click
        Me.Show()
        balans.Show()
    End Sub
End Class
