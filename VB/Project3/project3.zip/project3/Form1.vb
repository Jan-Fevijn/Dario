﻿Imports MySql.Data.MySqlClient
Imports System.Data.Sql
Imports System
Imports System.Data
Imports System.Data.OleDb
Public Class frmToevoegenBrood

    Dim todaysdate As String = String.Format("{0:dd/MM/yyyy}", DateTime.Now)
    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Dim Brood As New broodtype
        Dim eigenschap As New broodpositiedatum
        Brood.broodnaam = txtbrood.Text
        eigenschap.aantalIn = nmrAantal.Value
        eigenschap.kostprijs = nmrPrijs.Value
        eigenschap.Datum = todaysdate
        eigenschap.positie = nmrCode.Value
        broodpositiedatum.GetOne(eigenschap.idbroodpositieDatum)
        broodtype.GetOne(Brood.idbroodtype)
        Brood.Add()
        eigenschap.Add()
        MessageBox.Show("Het brood is toegevoegd")

    End Sub

    Private Sub SaldoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaldoToolStripMenuItem.Click
        Me.Show()
        balans.Show()
    End Sub
End Class
