﻿Public Class prodger

    Private _idprodger As Integer
    Private _idprod As Integer
    Private _idger As Integer
    Private _naamprod As String
    Private _naamger As String
    Public id = Idprodger

    Public Sub New(idprodger As Integer, idprod As Integer, idger As Integer, naamprod As Integer, naamger As String)
        _idprodger = idprodger
        _idprod = idprod
        _idger = idger
        _naamprod = naamprod
        _naamger = naamger
    End Sub

    Public Property Idprodger() As Integer
        Get
            Return _idprodger
        End Get
        Set(ByVal value As Integer)
            _idprodger = value
        End Set
    End Property

    Public Property Idprod() As Integer
        Get
            Return _idprod
        End Get
        Set(ByVal value As Integer)
            _idprod = value
        End Set
    End Property

    Public Property IdGer() As Integer
        Get
            Return _idger
        End Get
        Set(ByVal value As Integer)
            _idger = value
        End Set
    End Property

    Public Property Naamprod() As String
        Get
            Return _naamprod
        End Get
        Set(ByVal value As String)
            _naamprod = value
        End Set
    End Property

    Public Property Naamger() As String
        Get
            Return _naamger
        End Get
        Set(ByVal value As String)
            _naamger = value
        End Set
    End Property

    Public Overrides Function ToString() As String
        Return Naamprod & " / " & Naamger
    End Function
End Class
