﻿Public Class Evenementclass

    Private _id As Integer
    Private _naam As String
    Private _personen As Integer
    Private _dagen As Integer

    Public Sub New(id As Integer, naam As String, personen As Integer, dagen As Integer)
        _id = id
        _naam = naam
        _personen = personen
        _dagen = dagen
    End Sub

    Public Property Id() As Integer
        Get
            Return _id
        End Get
        Set(ByVal value As Integer)
            _id = value
        End Set
    End Property

    Public Property Naam() As String
        Get
            Return _naam
        End Get
        Set(ByVal value As String)
            _naam = value
        End Set
    End Property

    Public Property Personen() As Integer
        Get
            Return _personen
        End Get
        Set(ByVal value As Integer)
            _personen = value
        End Set
    End Property

    Public Property Dagen() As Integer
        Get
            Return _dagen
        End Get
        Set(ByVal value As Integer)
            _dagen = value
        End Set
    End Property

    Public Overrides Function ToString() As String
        Return Id & " / " & Naam & " / " & Personen & " / " & Dagen
    End Function
End Class
