﻿Imports MySql.Data.MySqlClient
Imports System.Data.Sql
Imports System
Imports System.Data
Imports System.Data.OleDb
Public Class Evenmenten

    Public conn As MySqlConnection
    Public connstring As String = "server=localhost;Port=3307;database=project2;uid=root;password=usbw; "
    Public datalijsteve As New List(Of Evenementclass)
    Public datalijstger As New List(Of Gerechtclass)
    Dim mySelectQuery As String = "select * from evenementen"

    Private Sub Evenmenten_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loaddata()
    End Sub

    Public Sub loaddata()
        conn = New MySqlConnection(connstring)

        conn.Open()

        'Dim mySelectQuery As String = "select * from evenementen"
        Dim mySelectQueryger As String = "select * from gerecht"

        Dim myCommand As New MySqlCommand(mySelectQuery, conn)
        Dim myCommandger As New MySqlCommand(mySelectQueryger, conn)

        Dim rd As MySqlDataReader
        rd = myCommand.ExecuteReader()
        While (rd.Read())
            datalijsteve.Add(New Evenementclass(rd(0), rd(1), rd(2), rd(3)))
        End While

        For Each evenement In datalijsteve
            ListBox1.Items.Add(evenement)
        Next

        rd.Close()

        For Each gerecht In Gerechten.datalijst
            cbGerechten.Items.Add(gerecht)
        Next

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim Commandins As New MySqlCommand("INSERT INTO `evenementen`(`naameve`,`dagen`,`aantal`) VALUES(@eve,@dag,@aan)", conn)

        Commandins.Parameters.Add("@eve", MySqlDbType.VarChar).Value = txtEvenement.Text
        Commandins.Parameters.Add("@dag", MySqlDbType.VarChar).Value = txtDagen.Text
        Commandins.Parameters.Add("@aan", MySqlDbType.VarChar).Value = txtPersonen.Text

        If Commandins.ExecuteNonQuery() = 1 Then
            MessageBox.Show("gelukt!")
            ListBox1.Refresh()
            txtEvenement.Clear()
            txtDagen.Clear()
            txtPersonen.Clear()
        Else
            MessageBox.Show("niet gelukt!")
        End If

        'bedoeling hier is dat als er een evenment wordt aangemaakt dat je een gerecht kan aanklikken en linken een je evenement
        'hier wil ik een insert van 2 id's in de koppeltabel gerechtevenement maar heb geen idee hoe en heb het ook niet gevonden
        'volgens mij mis een een class dus heb ik 1 gemaakt 
        Dim sql As New MySqlCommand("select * from gerecht where idgerecht = '" & "@naam" & "'", conn)

        sql.Parameters.Add("@naam", MySqlDbType.VarChar).Value = cbGerechten.SelectedIndex


        Dim Commandboth As New MySqlCommand("INSERT INTO `gerechtevenementen`(`idevenementen`,`idgerecht`) VALUES(@eve,@naam)", conn)

        conn.Close()
    End Sub

    Private Sub ProductenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductenToolStripMenuItem.Click
        Product.Show()
        Me.Hide()
    End Sub

    Private Sub GerechtenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GerechtenToolStripMenuItem.Click
        Gerechten.Show()
        Me.Hide()
    End Sub
End Class