﻿Imports MySql.Data.MySqlClient
Imports System.Data.Sql
Imports System
Imports System.Data
Imports System.Data.OleDb
Public Class Gerechten

    Public conn As MySqlConnection
    Public connstring As String = "server=localhost;Port=3307;database=project2;uid=root;password=usbw; "
    Public datalijst As New List(Of Gerechtclass)

    Private Sub Gerechten_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loaddata()
    End Sub

    Public Sub loaddata()
        conn = New MySqlConnection(connstring)

        conn.Open()

        Dim mySelectQuery As String = "select * from gerecht"

        Dim myCommand As New MySqlCommand(mySelectQuery, conn)

        Dim rd As MySqlDataReader
        rd = myCommand.ExecuteReader()
        While (rd.Read())
            datalijst.Add(New Gerechtclass(rd(0), rd(1)))
        End While

        For Each gerecht In datalijst
            ListBox1.Items.Add(gerecht)
            Evenmenten.cbGerechten.Items.Add(gerecht)
        Next

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        Dim Command As New MySqlCommand("INSERT INTO `gerecht`(`naamger`) VALUES(@ger)", conn)

        Command.Parameters.Add("@ger", MySqlDbType.VarChar).Value = txtGerecht.Text

        If Command.ExecuteNonQuery() = 1 Then
            MessageBox.Show("gelukt!")
            ListBox1.Refresh()
            txtGerecht.Clear()
        Else
            MessageBox.Show("niet gelukt!")
        End If

        conn.Close()

    End Sub




    Private Sub ProductenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductenToolStripMenuItem.Click
        Product.Show()
        Me.Hide()
    End Sub

    Private Sub EvenementenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EvenementenToolStripMenuItem.Click
        Evenmenten.Show()
        Me.Hide()
    End Sub
End Class