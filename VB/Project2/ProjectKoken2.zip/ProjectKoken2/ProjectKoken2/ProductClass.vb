﻿Public Class ProductClass
    Private _id As Integer
    Private _naam As String
    Private _aantal As String
    Private _winkel As String

    Public Sub New(id As Integer, naam As String)
        _id = id
        _naam = naam
    End Sub

    Public Property Id() As Integer
        Get
            Return _id
        End Get
        Set(ByVal value As Integer)
            _id = value
        End Set
    End Property

    Public Property Naam() As String
        Get
            Return _naam
        End Get
        Set(ByVal value As String)
            _naam = value
        End Set
    End Property

    Public Property Aantal() As String
        Get
            Return _aantal
        End Get
        Set(ByVal value As String)
            _aantal = value
        End Set
    End Property


    Public Property Winkel() As String
        Get
            Return _winkel
        End Get
        Set(ByVal value As String)
            _winkel = value
        End Set
    End Property
End Class
