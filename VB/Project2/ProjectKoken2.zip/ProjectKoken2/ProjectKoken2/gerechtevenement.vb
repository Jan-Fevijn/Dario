﻿Public Class gerechtevenement
    Private _ideve As String
    Private _idger As String
    Private _hoeveelheid As String
    Private _eenheid As String

    Public Sub New(ideve As String, idger As String, hoeveelheid As String, eenheid As String)
        _ideve = ideve
        _idger = idger
        _hoeveelheid = hoeveelheid
        _eenheid = eenheid
    End Sub

    Public Property Ideve() As String
        Get
            Return _ideve
        End Get
        Set(ByVal value As String)
            _ideve = value
        End Set
    End Property

    Public Property IdGer() As String
        Get
            Return _idger
        End Get
        Set(ByVal value As String)
            _idger = value
        End Set
    End Property

    Public Property Hoeveelheid() As String
        Get
            Return _hoeveelheid
        End Get
        Set(ByVal value As String)
            _hoeveelheid = value
        End Set
    End Property
    Public Property Eenheid() As String
        Get
            Return _eenheid
        End Get
        Set(ByVal value As String)
            _eenheid = value
        End Set
    End Property
End Class
