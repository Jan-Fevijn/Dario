﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Product
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ProductToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GerechtenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EvenementenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lstProdger = New System.Windows.Forms.ListBox()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.cbGer = New System.Windows.Forms.ComboBox()
        Me.cbProd = New System.Windows.Forms.ComboBox()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProductToolStripMenuItem, Me.GerechtenToolStripMenuItem, Me.EvenementenToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(893, 28)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ProductToolStripMenuItem
        '
        Me.ProductToolStripMenuItem.Name = "ProductToolStripMenuItem"
        Me.ProductToolStripMenuItem.Size = New System.Drawing.Size(90, 24)
        Me.ProductToolStripMenuItem.Text = "Producten"
        '
        'GerechtenToolStripMenuItem
        '
        Me.GerechtenToolStripMenuItem.Name = "GerechtenToolStripMenuItem"
        Me.GerechtenToolStripMenuItem.Size = New System.Drawing.Size(90, 24)
        Me.GerechtenToolStripMenuItem.Text = "Gerechten"
        '
        'EvenementenToolStripMenuItem
        '
        Me.EvenementenToolStripMenuItem.Name = "EvenementenToolStripMenuItem"
        Me.EvenementenToolStripMenuItem.Size = New System.Drawing.Size(112, 24)
        Me.EvenementenToolStripMenuItem.Text = "Evenementen"
        '
        'lstProdger
        '
        Me.lstProdger.FormattingEnabled = True
        Me.lstProdger.ItemHeight = 16
        Me.lstProdger.Location = New System.Drawing.Point(327, 209)
        Me.lstProdger.Name = "lstProdger"
        Me.lstProdger.Size = New System.Drawing.Size(269, 164)
        Me.lstProdger.TabIndex = 1
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(631, 115)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(75, 23)
        Me.btnUpdate.TabIndex = 2
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'cbGer
        '
        Me.cbGer.FormattingEnabled = True
        Me.cbGer.Location = New System.Drawing.Point(398, 150)
        Me.cbGer.Name = "cbGer"
        Me.cbGer.Size = New System.Drawing.Size(121, 24)
        Me.cbGer.TabIndex = 3
        '
        'cbProd
        '
        Me.cbProd.FormattingEnabled = True
        Me.cbProd.Location = New System.Drawing.Point(398, 71)
        Me.cbProd.Name = "cbProd"
        Me.cbProd.Size = New System.Drawing.Size(121, 24)
        Me.cbProd.TabIndex = 4
        '
        'Product
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(893, 399)
        Me.Controls.Add(Me.cbProd)
        Me.Controls.Add(Me.cbGer)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.lstProdger)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Product"
        Me.Text = "Form1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ProductToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GerechtenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EvenementenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lstProdger As ListBox
    Friend WithEvents btnUpdate As Button
    Friend WithEvents cbGer As ComboBox
    Friend WithEvents cbProd As ComboBox
End Class
