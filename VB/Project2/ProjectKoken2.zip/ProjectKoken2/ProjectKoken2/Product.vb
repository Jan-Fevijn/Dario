﻿Imports MySql.Data.MySqlClient
Imports System.Data.Sql
Imports System
Imports System.Data
Imports System.Data.OleDb
Public Class Product

    Public conn As MySqlConnection
    Public connstring As String = "server=localhost;Port=3307;database=project2;uid=root;password=usbw; "
    Dim datalijst As New List(Of prodger)

    Private Sub GerechtenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GerechtenToolStripMenuItem.Click
        Gerechten.Show()
        Me.Hide()
    End Sub

    Private Sub EvenementenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EvenementenToolStripMenuItem.Click
        Evenmenten.Show()
        Me.Hide()
    End Sub

    Private Sub Product_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loaddata()
    End Sub

    Private Sub loaddata()
        conn = New MySqlConnection(connstring)

        conn.Open()

        Dim mySelectQuery As String = "select idgerprod,idproduct, idgerecht, naamprod,naamger from prodger"

        Dim myCommand As New MySqlCommand(mySelectQuery, conn)

        Dim rd As MySqlDataReader
        rd = myCommand.ExecuteReader()
        While (rd.Read())
            datalijst.Add(New prodger(rd(0), rd(1), rd(2), rd(3), rd(4)))
        End While

        For Each prod In datalijst
            lstProdger.Items.Add(prod)
        Next

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim Command As New MySqlCommand("update `gerechtproduct` set idgerecht = @ger, idproduct = @ger where idgerechtproduct = prodger.id", conn)

        Command.Parameters.Add("@prod", MySqlDbType.VarChar).Value = cbProd.SelectedIndex
        Command.Parameters.Add("@ger", MySqlDbType.VarChar).Value = cbGer.SelectedIndex

        If Command.ExecuteNonQuery() = 1 Then
            MessageBox.Show("gelukt!")
            lstProdger.Refresh()
        Else
            MessageBox.Show("niet gelukt!")
        End If

        conn.Close()
    End Sub
End Class
